<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

$dataFile = 'content.json';
$secretKey = 'Legalitas@2025!Secure';

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Detect Endpoint
$requestUri = $_SERVER['REQUEST_URI'];
$isVerify = strpos($requestUri, 'verify-key') !== false;

$headers = getallheaders();
$auth = isset($headers['Authorization']) ? $headers['Authorization'] : '';

if ($isVerify) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($auth === $secretKey) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
        }
    } else {
        http_response_code(405); // Method Not Allowed
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($dataFile)) {
        echo file_get_contents($dataFile);
    } else {
        echo json_encode([]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Simple Auth Check
    if ($auth !== $secretKey) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    if ($input) {
        // Add updated timestamp
        $input['updated_at'] = date('c');
        
        if (file_put_contents($dataFile, json_encode($input, JSON_PRETTY_PRINT))) {
            echo json_encode(['success' => true, 'data' => $input]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to save file']);
        }
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON']);
    }
    exit;
}
?>
